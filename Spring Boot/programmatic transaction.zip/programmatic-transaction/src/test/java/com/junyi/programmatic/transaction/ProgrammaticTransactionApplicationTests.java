package com.junyi.programmatic.transaction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgrammaticTransactionApplicationTests {

	@Test
	void contextLoads() {
	}

}
